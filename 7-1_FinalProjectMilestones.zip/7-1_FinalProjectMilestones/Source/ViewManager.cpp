///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>    

// declaration of the global variables and defines
namespace
{
	// Variables for window width and height
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;
	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";

	// camera object used for viewing and interacting with
	// the 3D scene
	Camera* g_pCamera = nullptr;

	// these variables are used for mouse movement processing
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// time between current frame and last frame
	float gDeltaTime = 0.0f;
	float gLastFrame = 0.0f;

	// if orthographic projection is on, this value will be
	// true
	bool bOrthographicProjection = false;

	// Flag to track camera lock state
	bool g_CameraLocked = false;
}

/***********************************************************
 *  ViewManager()
 *
 *  The constructor for the class
 ***********************************************************/
ViewManager::ViewManager(
	ShaderManager* pShaderManager)
{
	// initialize the member variables
	m_pShaderManager = pShaderManager;
	m_pWindow = NULL;
	g_pCamera = new Camera();
	// default camera view parameters
	g_pCamera->Position = glm::vec3(22.8432, 14.8075, 26.4342);
	g_pCamera->Front = glm::vec3(-0.535951, -0.233343, -0.811361);
	g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
	g_pCamera->Zoom = 45;
	g_pCamera->Yaw -= 45.0f;
	
}


/***********************************************************
 *  ~ViewManager()
 *
 *  The destructor for the class
 ***********************************************************/
ViewManager::~ViewManager()
{
	// free up allocated memory
	m_pShaderManager = NULL;
	m_pWindow = NULL;
	if (NULL != g_pCamera)
	{
		delete g_pCamera;
		g_pCamera = NULL;
	}
}

/***********************************************************
 *  CreateDisplayWindow()
 *
 *  This method is used to create the main display window.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
	GLFWwindow* window = nullptr;

	// try to create the displayed OpenGL window
	window = glfwCreateWindow(
		WINDOW_WIDTH,
		WINDOW_HEIGHT,
		windowTitle,
		NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return NULL;
	}
	glfwMakeContextCurrent(window);

	// this callback is used to receive mouse moving events
	glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);

	//this callback is used to receive mouse wheel scrolling events
	glfwSetScrollCallback(window, &ViewManager::Mouse_Wheel_Callback);

	// tell GLFW to capture all mouse events
	//glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// enable blending for supporting tranparent rendering
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	m_pWindow = window;

	return(window);
}

/***********************************************************
 *  Mouse_Position_Callback()
 *
 *  This method is automatically called from GLFW whenever
 *  the mouse is moved within the active GLFW display window.
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos)
{
	if (g_CameraLocked) {
		// If camera is locked, do nothing
		return;
	}
	// calculate the offset of mouse position from the center of the window
	float xOffset = xMousePos - WINDOW_WIDTH / 2.0f;
	float yOffset = WINDOW_HEIGHT / 2.0f - yMousePos; // reversed y-axis

	// set the sensitivity for mouse movement
	float sensitivity = 0.0005f;

	// apply sensitivity to the offsets
	xOffset *= sensitivity;
	yOffset *= sensitivity;

	// update the yaw and pitch angles of the camera based on mouse movement
	g_pCamera->Yaw += xOffset;
	g_pCamera->Pitch += yOffset;

	// clamp the pitch angle to prevent flipping
	if (g_pCamera->Pitch > 89.0f)
		g_pCamera->Pitch = 89.0f;
	if (g_pCamera->Pitch < -89.0f)
		g_pCamera->Pitch = -89.0f;

	// clamp the yaw angle to keep it within a full circle
	while (g_pCamera->Yaw > 360.0f)
		g_pCamera->Yaw -= 360.0f;
	while (g_pCamera->Yaw < 0.0f)
		g_pCamera->Yaw += 360.0f;

	// update the front vector of the camera
	glm::vec3 front;
	front.x = cos(glm::radians(g_pCamera->Yaw)) * cos(glm::radians(g_pCamera->Pitch));
	front.y = sin(glm::radians(g_pCamera->Pitch));
	front.z = sin(glm::radians(g_pCamera->Yaw)) * cos(glm::radians(g_pCamera->Pitch));
	g_pCamera->Front = glm::normalize(front);
}
   // camera lock setting 
	void ViewManager::ToggleCameraLock()
	{
		g_CameraLocked = !g_CameraLocked;
	}

/***********************************************************
 *  Mouse_Wheel_Callback()
 *
 *  This method is called to process any keyboard events
 *  that may be waiting in the event queue.
 ***********************************************************/
void ViewManager::Mouse_Wheel_Callback(GLFWwindow* window, double x, double yScrollDistance)
{
	//call the camera class to process the mouse wheel scrolling
	g_pCamera->ProcessMouseScroll(yScrollDistance);
}

/***********************************************************
 *  ProcessKeyboardEvents()
 *
 *  This method automatically called from FLFW whenever
 * the mouse wheel is scrolled
 ***********************************************************/

void ViewManager::ProcessKeyboardEvents()
{
	// close the window if the escape key has been pressed
	if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(m_pWindow, true);
	}

	// if the camera object is null, then exit this method
	if (NULL == g_pCamera)
	{
		return;
	}

	// process camera zooming in and out
	if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime);
	}

	// process camera panning left and right
	if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(LEFT, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime);
	}

	// process camera moving up and down
	if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(UP, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(DOWN, gDeltaTime);
	}
	// Toggle camera lock on "L" key press
	if (glfwGetKey(m_pWindow, GLFW_KEY_L) == GLFW_PRESS)
	{
		ToggleCameraLock();
	}
	// Check if the 'P' key is pressed
	if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS)
	{
		// Set perspective projection mode
		bOrthographicProjection = false;
	}

	// Check if the 'O' key is pressed
	if (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS)
	{
		// Set orthographic projection mode
		bOrthographicProjection = true;
	}

}

/***********************************************************
 *  PrepareSceneView()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ********************************************************

***/
void ViewManager::PrepareSceneView()
{
	glm::mat4 view;
	glm::mat4 projection;

	// per-frame timing
	float currentFrame = glfwGetTime();
	gDeltaTime = currentFrame - gLastFrame;
	gLastFrame = currentFrame;

	// Method to process keyboard events
	ProcessKeyboardEvents();

	/*Output the final camera position commented out when not in use
	std::cout << "Final Camera Properties:" << std::endl;
	std::cout << "Position: (" << g_pCamera->Position.x << ", " << g_pCamera->Position.y << ", " << g_pCamera->Position.z << ")" << std::endl;
	std::cout << "Front: (" << g_pCamera->Front.x << ", " << g_pCamera->Front.y << ", " << g_pCamera->Front.z << ")" << std::endl;
	std::cout << "Up: (" << g_pCamera->Up.x << ", " << g_pCamera->Up.y << ", " << g_pCamera->Up.z << ")" << std::endl;
	std::cout << "Zoom: " << g_pCamera->Zoom << std::endl;
	*/


	// get the current view matrix from the camera
	view = g_pCamera->GetViewMatrix();

	// Define the projection matrix based on user selection
	if (bOrthographicProjection) {
		// Define the orthographic projection parameters
		float orthoLeft = -30.0f;   // Adjust this value based on the scene's dimensions
		float orthoRight = 30.0f;   // Adjust this value based on the scene's dimensions
		float orthoBottom = -30.0f;   // Set the bottom plane just below the scene
		float orthoTop = 30.0f;     // Adjust this value based on the scene's dimensions
		float orthoNear = -100.0f;   // Adjust this value based on the scene's depth
		float orthoFar = 50.0f;

		projection = glm::ortho(orthoLeft, orthoRight, orthoBottom, orthoTop, orthoNear, orthoFar);
	}
	else {
		// Perspective projection parameters
		projection = glm::perspective(glm::radians(g_pCamera->Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
	}

	// if the shader manager object is valid
	if (NULL != m_pShaderManager)
	{
		// set the view matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ViewName, view);
		// set the projection matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ProjectionName, projection);
		// set the view position of the camera into the shader for proper rendering
		m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
	}
}


